// Portfolio scripts: no libraries, no external calls, passive listeners.
(function () {
  "use strict";

  // Hide intro after its animation (also removed in reduced-motion via CSS)
  var intro = document.getElementById("intro");
  if (intro) {
    setTimeout(function () { intro.classList.add("hide"); }, 2400);
  }

  // Reveal each panel in 3D when it enters the screen
  var panels = document.querySelectorAll(".panel");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    panels.forEach(function (p) { io.observe(p); });
  } else {
    panels.forEach(function (p) { p.classList.add("in"); });
  }

  // Scroll-linked tilt of the hero ring, throttled with requestAnimationFrame
  var ring = document.getElementById("ring");
  var ticking = false;
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function updateRing() {
    ticking = false;
    if (!ring) return;
    var y = window.scrollY;
    var tilt = Math.min(y / 40, 35);
    ring.style.transform = "rotateX(" + (-tilt) + "deg)";
  }

  if (!reduce && ring) {
    window.addEventListener("scroll", function () {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(updateRing);
      }
    }, { passive: true });
  }

  // Mouse tilt on desktop only (touch devices skip this to keep scrolling smooth)
  var hero = document.getElementById("top");
  if (hero && window.matchMedia("(hover: hover)").matches && !reduce && ring) {
    hero.addEventListener("mousemove", function (e) {
      var x = (e.clientX / window.innerWidth - 0.5) * 16;
      var z = (e.clientY / window.innerHeight - 0.5) * -12;
      ring.style.transform = "rotateX(" + z + "deg) rotateY(" + x + "deg)";
    }, { passive: true });
  }
})();
